export const settings = {
  theme: {
    skin: "dark",
  },
};
export default { settings };
