export interface BlogPost {
  id: string;
  post_img: string;
  post_title: string;
  post_date: string;
  author: string;
  post_views: string;
  post_subscriber: string;
  post_likes: string;
  post_comments: string;
  post_status: string;
}
