# Dasher UI - Minimal Next.js Admin Dashboard Template

#### Preview

- [Demo](https://themewagon.github.io/dasher-ui/)

#### Download

- [Download from ThemeWagon](https://themewagon.com/themes/dasher-ui/)

## Getting Started

1. Clone Repository

```
git clone https://github.com/themewagon/dasher-ui.git
```

## Author

```
Design and code is completely written by codescandy design and development team.
```

## License

- Design and Code is Copyright &copy; [@Codescandy](https://codescandy.com/)
- Licensed cover under [MIT]
- Distributed by [ThemeWagon](https://themewagon.com)
