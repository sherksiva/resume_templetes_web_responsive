# Resume - Free Next.js Resume Website Template
#### Preview

 - [Demo](https://themewagon.github.io/Resume-Nextjs/)

#### Download
 - [Download from ThemeWagon](https://themewagon.com/themes/resume-nextjs/)


## Getting Started

Clone from GitHub 
```bash
git clone https://github.com/themewagon/Resume-Nextjs.git
```

Install dependencies:
```bash
npm install
```

Run development server:
```bash
npm run dev
```

Build for production:
```bash
npm run build
```

## Author

Design and code are written by the getnextjstemplates design & development team.  


## License

 - Design and Code is Copyright &copy; [getnextjstemplates](https://getnextjstemplates.com/)
 - Licensed under [MIT]
 - Distributed by [ThemeWagon](https://themewagon.com)





