// ===============================|| Blank Layout ||=============================== //
<template>
  <v-app>
    <RouterView />
  </v-app>
</template>
<script setup lang="ts">
import { RouterView } from 'vue-router';
</script>
