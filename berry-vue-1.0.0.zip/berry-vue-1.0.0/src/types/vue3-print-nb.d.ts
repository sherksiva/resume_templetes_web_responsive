declare module 'vue3-print-nb';
